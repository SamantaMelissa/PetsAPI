﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API_Pet.Domains
{
    public class TipoDePet
    {
        public int IdTipoDePet { get; set; }

        public string Descricao { get; set; }
    }
}
