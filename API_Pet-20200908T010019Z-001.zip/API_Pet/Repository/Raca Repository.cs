﻿using API_Pet.Context;
using API_Pet.Domains;
using API_Pet.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace API_Pet.Repository
{
    public class Raca_Repository : IRaca

    {
        PetContext conexao = new PetContext();

        SqlCommand cmd = new SqlCommand();


        public Raca Alterar(Raca a)
        {
         cmd.Connection = conexao.Conectar();
          
            cmd.CommandText = "UPDATE Raca SET Descricao= @descricao,IdTipoDePet=@idtipodepet WHERE IdRaca = @id";
            cmd.Parameters.AddWithValue("@descricao", a.Descricao);
            cmd.Parameters.AddWithValue("@idtipodepet", a.IdTipoDePet);
            
            cmd.ExecuteNonQuery();

            conexao.Desconectar();
         
            return a;
        }

        public Raca BuscarPorId(int id)
        {
            cmd.Connection = conexao.Conectar();
            

            cmd.CommandText = "SELECT * FROM Raca WHERE IdRaca = @id";
            cmd.Parameters.AddWithValue("@id", id);
           
            SqlDataReader dados = cmd.ExecuteReader();
            Raca r= new Raca();

            while (dados.Read())
            {
                r.IdRaca = Convert.ToInt32(dados.GetValue(0));
                r.Descricao = dados.GetValue(1).ToString();
                r.IdTipoDePet = Convert.ToInt32(dados.GetValue(2));
            }
            
            
            conexao.Desconectar();
            return r;
        }

        public Raca Cadastrar(Raca a)
        {
            cmd.Connection = conexao.Conectar();

            cmd.CommandText = "INSERT INTO Raca (Descricao, IdTipoDePet)" +
                "VALUES" +
                "(@descricao, @idtipodepet)";
            cmd.Parameters.AddWithValue("@descricao", a.Descricao);
            cmd.Parameters.AddWithValue("@idtipopet", a.IdTipoDePet);

           
            cmd.ExecuteNonQuery();

       
            conexao.Desconectar();

            return a;
        }

        public void Excluir(int id)
        {
            cmd.Connection = conexao.Conectar();

            cmd.CommandText = "DELETE FROM Raca Where IdRaca = @id";

            cmd.ExecuteNonQuery();

            conexao.Desconectar();

            



        }

        public List<Raca> LerTodos()
        {
            cmd.Connection = conexao.Conectar();

            cmd.CommandText = "SELECT * FROM Raca";

            SqlDataReader dados = cmd.ExecuteReader();

            List<Raca> racas = new List<Raca>();


            while (dados.Read())
            {
                racas.Add(
                    new Raca
                    {
                        IdRaca = Convert.ToInt32(dados.GetValue(0)),
                        Descricao = dados.GetValue(1).ToString(),
                        IdTipoDePet = Convert.ToInt32(dados.GetValue(2)),
                        
                    }
                );
            }
            
            conexao.Desconectar();

            return racas;

        }
    }
}
