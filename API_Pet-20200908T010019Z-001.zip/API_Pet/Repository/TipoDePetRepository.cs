﻿using API_Pet.Context;
using API_Pet.Domains;
using API_Pet.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace API_Pet.Repository
{
    public class TipoDePetRepository : ITipoDePet
    {

        PetContext conexao = new PetContext();

        SqlCommand cmd = new SqlCommand();

        public TipoDePet Alterar(TipoDePet b)
        {
            cmd.Connection = conexao.Conectar();
            
            cmd.CommandText = "UPDATE TipoDePet SET Descricao= @descricao WHERE IdTipoDePet = @id";
            cmd.Parameters.AddWithValue("@descricao", b.Descricao);
            cmd.Parameters.AddWithValue("@id", b.IdTipoDePet);
            
            cmd.ExecuteNonQuery();

            conexao.Desconectar();
          
            return b;
        }

        public TipoDePet BuscarPorId(int id)
        {
            cmd.Connection = conexao.Conectar();
           
            cmd.CommandText = "SELECT * FROM TipoDePet WHERE IdTipoDePet = @id";
            cmd.Parameters.AddWithValue("@id", id);
            
            SqlDataReader dados = cmd.ExecuteReader();
            TipoDePet p = new TipoDePet();

            while (dados.Read())
            {
                p.IdTipoDePet = Convert.ToInt32(dados.GetValue(0));
                p.Descricao = dados.GetValue(1).ToString();
            }

            conexao.Desconectar();
            return p;
        }

        public TipoDePet Cadastrar(TipoDePet b)
        {
            cmd.Connection = conexao.Conectar();

            cmd.CommandText = "INSERT INTO TipoDePet(Descricao)" +
                "VALUES" +
                "(@descricao)";
            cmd.Parameters.AddWithValue("@descricao", b.Descricao);

            
            cmd.ExecuteNonQuery();

            conexao.Desconectar();

            return b;
        }

        public void Excluir(int id)
        {
            cmd.Connection = conexao.Conectar();

            cmd.CommandText = "DELETE FROM TipoDePet Where IdTipoDePet = @id";

            cmd.ExecuteNonQuery();

            conexao.Desconectar(); 
        }

        public List<TipoDePet> LerTodos()
        {
            cmd.Connection = conexao.Conectar();

            cmd.CommandText = "SELECT * FROM TipoDePet";

            SqlDataReader dados = cmd.ExecuteReader();

            List<TipoDePet> tipo = new List<TipoDePet>();


            while (dados.Read())
            {
                tipo.Add(
                    new TipoDePet

                    {
                        IdTipoDePet = Convert.ToInt32(dados.GetValue(0)),
                        Descricao = dados.GetValue(1).ToString(),

                    }
                );
            }

            conexao.Desconectar();

            return tipo;

        
        }
    }
}
