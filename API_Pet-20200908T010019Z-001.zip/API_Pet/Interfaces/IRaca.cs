﻿using API_Pet.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API_Pet.Interfaces
{
    interface IRaca 
    {
        Raca Cadastrar(Raca a);

        List<Raca> LerTodos();

        Raca BuscarPorId(int id);

        Raca Alterar(Raca a);

        void Excluir(int id);


        

    }
}
