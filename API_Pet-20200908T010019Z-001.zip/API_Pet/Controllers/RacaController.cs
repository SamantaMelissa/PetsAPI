﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API_Pet.Domains;
using API_Pet.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API_Pet.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RacaController : ControllerBase
    {

        Raca_Repository rep = new Raca_Repository();

        // GET: api/Raca
        [HttpGet]
        public List<Raca> Get()
        {
            return rep.LerTodos();

        }

        // GET: api/Raca/5
        [HttpGet("{id}")]
        public Raca Get(int id)
        {
            return rep.BuscarPorId(id);
        }

        // POST: api/Raca
        [HttpPost]
        public void Post([FromBody] Raca a)
        {
            rep.Cadastrar(a);
        }

        // PUT: api/Raca/5
        [HttpPut("{id}")]
        public Raca Put(int id, [FromBody] Raca a)
        {
            return rep.Alterar(a);
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            rep.Excluir(id);
        }
    }
}
