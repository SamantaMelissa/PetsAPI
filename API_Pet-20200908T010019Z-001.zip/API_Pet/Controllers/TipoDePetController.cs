﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API_Pet.Domains;
using API_Pet.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API_Pet.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TipoDePetController : ControllerBase
    {

        TipoDePetRepository repo = new TipoDePetRepository();

        // GET: api/TipoPet
        [HttpGet]
        public List<TipoDePet> Get()
        {
            return repo.LerTodos();
        }

        // GET: api/TipoPet/5
        [HttpGet("{id}")]
        public TipoDePet Get(int id)
        {
            return repo.BuscarPorId(id);
        }

        // POST: api/TipoPet
        [HttpPost]
        public void Post([FromBody]TipoDePet b)
        {
            repo.Cadastrar(b);
        }

        // PUT: api/TipoPet/5
        [HttpPut("{id}")]
        public TipoDePet Put(int id, [FromBody] TipoDePet b)
        {
            return repo.Alterar(b);
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            repo.Excluir(id);
        }
    }
}
